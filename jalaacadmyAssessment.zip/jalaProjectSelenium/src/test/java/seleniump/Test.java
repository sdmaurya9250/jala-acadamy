package seleniump;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Test {

	public static  void main(String[] args) {
		
		System.setProperty("webdriver.firefox.marionette", "D:\\chromedriver\\edgedriver_win64 (1)\\geckodriver.exe");
		
    WebDriver driver = new FirefoxDriver();
//	String textBoxValue = textBox.getAttribute("value");
//	System.out.println("Text Box Value: " + textBoxValue);
	driver.quit();
	
//	//Alert Popup
//	driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_alert");
//	  driver.switchTo().frame("iframeResult"); 
//	  
//	  driver.findElement(By.xpath("//*[@onclick='myFunction()']")).click(); //
//	// click on Ok button 
//             driver.switchTo().alert().accept();

	
	
//	// Confirm Popup 
//    driver.navigate().to("https://www.w3schools.com/js/tryit.asp?filename=tryjs_confirm");
// 
// driver.switchTo().frame("iframeResult");
// driver.findElement(By.xpath("//*[@onclick='myFunction()']")).click();
// 
// System.out.println(driver.switchTo().alert().getText()); 
// // Click on OK 
//  driver.switchTo().alert().accept(); 
//  // click on cancel
// //driver.switchTo().alert().dismiss(); 
//	
//	
	
	
	
	
	//Prompt Popup
	
//			driver.navigate().to("https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
//
//			driver.switchTo().frame("iframeResult");
//			driver.findElement(By.xpath("//*[@onclick='myFunction()']")).click();
//			
//			System.out.println(driver.switchTo().alert().getText());
//			
//			driver.switchTo().alert().sendKeys("gaurav");
//			
//			driver.switchTo().alert().accept();
			
			
	
	
	
	
//	
//	driver.get("https://www.facebook.com/");
//	
//	driver.findElement(By.xpath("//div[@class='_6ltg'][2]")).click();
//	
//	driver.findElement(By.xpath("//input[@class='mbm _1iy_ _a4y _3-90 lfloat _ohe']")).sendKeys("Sakshi");
//	
//	driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Maurya");
//	driver.findElement(By.id("reg_email__")).sendKeys("8169818261");
//	driver.findElement(By.id("password_step_input")).sendKeys("sakshi123");
//	driver.navigate().back();
//	driver.navigate().refresh();
//	
////	boolean isdis= driver.findElement(By.className("mbm _1iy_ _a4y _3-90 lfloat _ohe")).isDisplayed();
////	System.out.println(isdis);
//	//Select slct=new Select();)
//	
		
	
	}

}
