package seleniump;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class demo {

	public static void main(String[] args) throws InterruptedException {
	

		System.setProperty("webdriver.firefox.marionette", "D:\\chromedriver\\edgedriver_win64 (1)\\geckodriver.exe");
   
	    WebDriver driver = new FirefoxDriver();	 
	    driver.manage().window().maximize();
	    driver.get("http://magnus.jalatechnologies.com/");
	    driver.getCurrentUrl();
	    driver.getTitle();
	    driver.getPageSource();
	    driver.findElement(By.id("UserName")).sendKeys("training@jalaacademy.com");
		driver.findElement(By.name("Password")).sendKeys("jobprogram");
		driver.findElement(By.id("btnLogin")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//a[@href='#'])[2]")).click();
		Thread.sleep(3000);
		 // WebElement element =	
				  driver.findElement(By.xpath("(//a[@href='/Employee/Search'])")).click();
		 driver.findElement(By.xpath("(//input[@class='form-control'])[1]")).sendKeys("Neha");
	
		
		
// // Get the tag name of the element
//        String tagName = element.getTagName();
//        // Print the tag name
//        System.out.println("Tag name: " + tagName);
        
		
	    driver.navigate().to("https://jalaacademy.com/");
			
		 ((WebElement) driver).isDisplayed();
	 ((WebElement) driver).isEnabled();
		 ((WebElement) driver).isSelected();
//		 driver.navigate().back();
//		 driver.navigate().forward();
//		 driver.navigate().refresh();
		
// get attribute
	//	    WebElement searchTextBox= driver.findElement(By.id("searchbox_input"));
	//
//		    // retrieving html attribute value using getAttribute() method
//		    String typeValue=searchTextBox.getAttribute("type");
//		    System.out.println("Value of type attribute: "+typeValue);

//		    String autocompleteValue=searchTextBox.getAttribute("autocomplete");
//		    System.out.println("Value of autocomplete attribute: "+autocompleteValue);

//		    // Retrieving value of attribute which does not exist
//		    String nonExistingAttributeValue=searchTextBox.getAttribute("nonExistingAttribute");
//		    System.out.println("Value of nonExistingAttribute attribute: "+nonExistingAttributeValue);

	     

//
//		   
//		 driver.getText();
//		
//		;
//		 driver.getSize();
//		 driver.getLocation();
		
//		 driver.quit();
//		 driver.close();
		
		
		
		
		
		
		//driver.switchTo().frame("iframeResult");
		

		// to get current window hadle
	//	String parentTab=driver.getWindowHandle();
		
//		Thread.sleep(3000);
//		driver.findElement(By.xpath("//a[@target='_blank']")).click();
//		
//		// to get all window id
//		Set<String> lstwindows=driver.getWindowHandles();
//		
//		// loop to iteate over each window
//		for (String string : lstwindows) {
//			// switching to window
//			driver.switchTo().window(string);
//			
//			System.out.println(driver.getTitle());
//			try {
//			//driver.findElement(By.id("search2")).sendKeys("Java");
//			}catch (Exception e) {
//				System.out.println("Not found in current window");
//		}
//		
//		// switching back to parent window
//		driver.switchTo().window(parentTab);
		
	    
	    
   
		
	}

}
