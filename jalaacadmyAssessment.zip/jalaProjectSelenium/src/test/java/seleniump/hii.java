package seleniump;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class hii {

	public static void main(String[] args) {
	
			System.setProperty("webdriver.edge.driver", "C:\\Users\\Administrator\\Downloads\\edgedriver_win64 (1)\\msedgedriver.exe");

			//use to launch the browser
			WebDriver driver=new ChromeDriver();
//			driver.get("https://www.facebook.com/");
//			
//			driver.findElement(By.id("email")).sendKeys("sakshi11@gmaill.com");
//
//			
//			boolean isDis=driver.findElement(By.id("email")).isDisplayed();
//			System.out.println(isDis);
//			
//			System.out.println(driver.findElement(By.id("email")).isEnabled());
//			
//			System.out.println(driver.findElement(By.id("email")).isSelected());
//			
//			//driver.navigate().forward();
		//	driver.navigate().back();
//			driver.navigate().refresh();
			
		}
	//	System.out.println(driver.getCurrentUrl());
		//System.out.println(driver.getPageSource());
		
		//driver.close();
		//driver.quit();
	
	
	
	}



