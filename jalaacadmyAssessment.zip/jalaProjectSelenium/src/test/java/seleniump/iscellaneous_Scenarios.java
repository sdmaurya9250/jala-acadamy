package seleniump;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

public class iscellaneous_Scenarios {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.firefox.marionette", "D:\\chromedriver\\edgedriver_win64 (1)\\geckodriver.exe");
		   
	    WebDriver driver = new FirefoxDriver();	 
	    driver.manage().window().maximize();
	    driver.get("http://magnus.jalatechnologies.com/");
	    driver.getCurrentUrl();
	    driver.getTitle();
	    driver.getPageSource();
	    driver.findElement(By.id("UserName")).sendKeys("training@jalaacademy.com");
		driver.findElement(By.name("Password")).sendKeys("jobprogram");
		driver.findElement(By.id("btnLogin")).click();
		Thread.sleep(3000);
		
		File scrfile =((Takescreenshot)driver.getScreenshot(outputType.File));
		
		//copy loction
		FileHandler.copy(scrfile, new File ("D:\\screenshot\\selenium test"));
	}

}
