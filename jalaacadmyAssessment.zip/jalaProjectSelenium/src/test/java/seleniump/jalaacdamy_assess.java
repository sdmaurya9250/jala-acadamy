package seleniump;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class jalaacdamy_assess {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.firefox.marionette", "D:\\chromedriver\\edgedriver_win64 (1)\\geckodriver.exe");
		
	    WebDriver driver = new FirefoxDriver();
	    driver.get("http://magnus.jalatechnologies.com/");
		driver.findElement(By.id("UserName")).sendKeys("training@jalaacademy.com");
		driver.findElement(By.name("Password")).sendKeys("jobprogram");
		driver.findElement(By.id("btnLogin")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//a[@href='#'])[2]")).click();
		driver.findElement(By.xpath("(//a[@href='/Employee/Create'])")).click();
	 driver.findElement(By.xpath("//input[@id='FirstName']")).sendKeys("sakshi");
	 driver.findElement(By.xpath("//input[@id='LastName']")).sendKeys("Maurya");
	 driver.findElement(By.xpath("//input[@id='EmailId']")).sendKeys("sakshi100@gmail.coms");
	 driver.findElement(By.xpath("//input[@id='MobileNo']")).sendKeys("@#@3434444");
	 driver.findElement(By.xpath("//input[@id='DOB']")).sendKeys("10/03/2005");
	
	 driver.findElement(By.xpath("//input[@value='F']")).click();
	
	  WebElement radioGroup = driver.findElement(By.xpath("//input[@value='F']"));
	  
//find out redio button value
//      // Find all radio buttons within the radio group
     List<WebElement> radioButtons = radioGroup.findElements(By.tagName("input"));
//
//      // Get the number of radio buttons in the group
//      int numberOfRadioButtons = radioButtons.size();
//
//      // Print the number of radio buttons
//      System.out.println("Number of radio buttons in the group: " + numberOfRadioButtons);
	 
//find out redio button value
   // Iterate through each radio button and print its value
//      for (WebElement radioButton : radioButtons) {
//          String radioButtonValue = radioButton.getAttribute("value");
//          System.out.println("Radio button value: " + radioButtonValue);
//      }
      
   //get selected radio button  //input[@value='F']
      WebElement selectedRadioButton = driver.findElement(By.cssSelector("//input[@id='rdbMale']"));

      // Find the label associated with the selected radio button
      WebElement labelElement = driver.findElement(By.xpath("//label[@for='" + selectedRadioButton.getAttribute("id") + "']"));

      // Retrieve the text of the label
      String selectedLabel = labelElement.getText();

      // Print the selected label text
      System.out.println("Selected Radio Button Label: " + selectedLabel);
      
      
//		String textBoxValue = textBox.getAttribute("value");
//		System.out.println("Text Box Value: " + textBoxValue);
		driver.quit();
		

	}

}
