package seleniump;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class popup_method {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.firefox.marionette", "D:\\chromedriver\\edgedriver_win64 (1)\\geckodriver.exe");
		   
	    WebDriver driver = new FirefoxDriver();	 
	    driver.manage().window().maximize();
	    driver.get("http://magnus.jalatechnologies.com/");
	    driver.getCurrentUrl();
	    driver.getTitle();
	    driver.getPageSource();
	    driver.findElement(By.id("UserName")).sendKeys("training@jalaacademy.com");
		driver.findElement(By.name("Password")).sendKeys("jobprogram");
		driver.findElement(By.id("btnLogin")).click();
		Thread.sleep(3000);
		
		// to get current window hadle
				driver.getWindowHandle();
		
//		driver.findElement(By.xpath("(//a[@href='#'])[3]")).click();
//		driver.findElement(By.xpath("//a[@href='/Home/Popup']")).click();
//		
//		 driver.findElement(By.xpath("//a[@id='btn-two']")).click(); //popup method
		 
		 
		//Alert Popup
//				driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_alert");
//				  driver.switchTo().frame("iframeResult"); 
//		 driver.findElement(By.xpath("//*[@onclick='myFunction()']")).click();
//				 // click on Ok button 
//		                 driver.switchTo().alert().accept();
				  
//		              // Confirm Popup 
//	                      driver.navigate().to(	"https://www.w3schools.com/js/tryit.asp?filename=tryjs_confirm");
//			 
//			  driver.switchTo().frame("iframeResult");
//			  driver.findElement(By.xpath("//*[@onclick='myFunction()']")).click();
//			  
//			//  System.out.println(driver.switchTo().alert().getText());
//			  
//			 // Click on OK 
//			  driver.switchTo().alert().accept(); // click on cancel
//			 driver.switchTo().alert().dismiss(); //
//       driver.close();
       
     //Prompt Popup
		
//     		driver.navigate().to("https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
//
//     		driver.switchTo().frame("iframeResult");
//     		driver.findElement(By.xpath("//*[@onclick='myFunction()']")).click();
//     		
//     		System.out.println(driver.switchTo().alert().getText());
//     		
//     		driver.switchTo().alert().sendKeys("sakshi");
//     		
//     		driver.switchTo().alert().accept();
	    
	    
	    
//driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_win_open");
//		
//		
//		driver.switchTo().frame("iframeResult");
//		
//		// to get current window hadle
//		String parentTab=driver.getWindowHandle();
//		
//		
//		driver.findElement(By.xpath("//button[@onClick='myFunction()']")).click();
//		
//		// to get all window id
//		Set<String> lstwindows=driver.getWindowHandles();
//		
//		// loop to iteate over each window
//		for (String string : lstwindows) {
//			// switching to window
//			driver.switchTo().window(string);
//			
//			System.out.println(driver.getTitle());
//			try {
//			driver.findElement(By.id("search2")).sendKeys("Java");
//			}catch (Exception e) {

		
		// switching back to parent window
	//	driver.switchTo().window(parentTab);
	}

}
