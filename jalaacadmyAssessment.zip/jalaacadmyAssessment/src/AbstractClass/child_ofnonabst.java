package AbstractClass;

public class child_ofnonabst {
	// SubclassExample.java
	public class child_ofnonabst extends AbstractExample {
	    // Implementing the abstract method from AbstractExample
	    @Override
	    public void abstractMethod() {
	        System.out.println("This is the implementation of abstractMethod() in SubclassExample");
	    }

	    public static void main(String[] args) {
	        // Creating an object of SubclassExample
	        SubclassExample example = new SubclassExample();

	        // Accessing non-abstract method from AbstractExample
	        example.nonAbstractMethod();
	    }
	}
}
