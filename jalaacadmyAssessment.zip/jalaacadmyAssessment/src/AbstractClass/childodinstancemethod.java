package AbstractClass;

public class childodinstancemethod extends instanceclass{

	
	    // Implementing the abstract method from AbstractExample
	    @Override
	    public void abstractMethod() {
	        System.out.println("This is the implementation of abstractMethod() in SubclassExample");
	    }

	    public static void main(String[] args) {
	        // Creating an object of SubclassExample
	    	instanceclass example = new instanceclass();

	        // Calling the abstract method from within the child class
	        example.abstractMethod();
	    }
	}

