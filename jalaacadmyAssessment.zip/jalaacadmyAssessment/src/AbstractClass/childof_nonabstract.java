package AbstractClass;

public class childof_nonabstract {

	// AbstractExample.java
	public abstract class AbstractExample {
	    // Abstract method (method without body)
	    public abstract void abstractMethod();

	    // Non-abstract method (method with body)
	    public void nonAbstractMethod() {
	        System.out.println("This is a non-abstract method in AbstractExample");
	    }
	}

