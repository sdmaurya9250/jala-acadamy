package AbstractClass;

public class childofabstrat extends firsttest {

	    // Implementing the abstract method from AbstractExample
	    @Override
	    public void abstractMethod1() {
	        System.out.println("This is the implementation of abstractMethod() in ConcreteExample");
	    }

	    public static void main(String[] args) {
	    	childofabstrat example = new childofabstrat();

	        // Calling abstract method
	        example.abstractMethod();

	        // Calling non-abstract method
	        example.nonAbstractMethod();
	    }
	}

	@Override
	public void abstractMethod() {
		// TODO Auto-generated method stub
		
	}

