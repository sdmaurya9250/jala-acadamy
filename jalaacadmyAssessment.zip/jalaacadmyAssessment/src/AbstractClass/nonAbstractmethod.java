package AbstractClass;

public class nonAbstractmethod {

}
