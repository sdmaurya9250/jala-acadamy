package AccessModifier;

public class Privateconstructer {

	    private int privateField1;
	    private String privateField2;

	    // Constructor
	    public Privateconstructer(int privateField1, String privateField2) {
	        this.privateField1 = privateField1;
	        this.privateField2 = privateField2;
	    }

	    // Private method
	    private void privateMethod() {
	        System.out.println("Private method called");
	        // You can access private fields within the class
	        System.out.println("Private Field 1: " + privateField1);
	        System.out.println("Private Field 2: " + privateField2);
	    }

	    public static void main(String[] args) {
	        // Create an instance of the class
	    	Privateconstructer example = new Privateconstructer(10, "Hello");

	        // Print the private fields
	        System.out.println("Printing private fields in main method:");
	        System.out.println("Private Field 1: " + example.privateField1);
	        System.out.println("Private Field 2: " + example.privateField2);

	        // Call the private method
	        System.out.println("\nCalling private method in main method:");
	        example.privateMethod();
	    }
	}

