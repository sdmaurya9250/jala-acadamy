package AccessModifier;

public class ProtectedMethod {
	
	    // Protected fields
	    protected int protectedField1;
	    protected String protectedField2;

	    // Protected constructor
	    protected ProtectedMethod(int protectedField1, String protectedField2) {
	        this.protectedField1 = protectedField1;
	        this.protectedField2 = protectedField2;
	    }

	    // Protected method
	    protected void protectedMethod() {
	        System.out.println("Protected Method Called");
	        System.out.println("Protected Field 1: " + protectedField1);
	        System.out.println("Protected Field 2: " + protectedField2);
	    }
	}

	
