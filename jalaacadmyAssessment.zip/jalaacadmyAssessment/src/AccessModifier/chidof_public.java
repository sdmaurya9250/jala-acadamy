package AccessModifier;

public class chidof_public {

	    private String publicField1;
		private String publicField2;

		public static void main(String[] args) {
	        // Creating an instance of PublicExample
	    	chidof_public example = new chidof_public();

	        // Accessing public fields
	        System.out.println("Accessing public fields:");
	        System.out.println("Public Field 1: " + example.publicField1);
	        System.out.println("Public Field 2: " + example.publicField2);

	        // Accessing public method
	        System.out.println("\nCalling public method:");
	        example.publicMethod();
	    }

		private void publicMethod() {
			// TODO Auto-generated method stub
			
		}
	}

