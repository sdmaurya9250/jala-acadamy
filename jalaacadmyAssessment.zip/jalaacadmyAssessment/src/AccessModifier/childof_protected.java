package AccessModifier;

public class childof_protected extends ProtectedMethod {

    // Constructor
	    public childof_protected(int protectedField1, String protectedField2) {
	        super(protectedField1, protectedField2);
	    }

	    // Method accessing protected members
	    public void accessProtected() {
	        System.out.println("Accessing protected members from ChildClass in a different package:");
	        System.out.println("Protected Field 1: " + protectedField1);
	        System.out.println("Protected Field 2: " + protectedField2);
	        protectedMethod();
	    }
	}

	