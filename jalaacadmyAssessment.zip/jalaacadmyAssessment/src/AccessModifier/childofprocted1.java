package AccessModifier;

public class childofprocted1 {

	
	    public static void main(String[] args) {
	        // Accessing protected members from any class in a different package
	    	childofprocted1 example = new childofprocted1();
	        System.out.println("Accessing protected members from AnotherClass in a different package:");
	        System.out.println("Protected Field 1: " + example.protectedField1);
	        System.out.println("Protected Field 2: " + example.protectedField1);
	        example.protectedMethod();
	    }
	}
