package AccessModifier;
//Class with default access modifier
public class defoultmethodconstructor {

	
	    // Default fields
	    int defaultField1;
	    String defaultField2;

	    // Default constructor
	    defoultmethodconstructor(int defaultField1, String defaultField2) {
	        this.defaultField1 = defaultField1;
	        this.defaultField2 = defaultField2;
	    }

	    // Default method
	    void defaultMethod() {
	        System.out.println("Default Method Called");
	        System.out.println("Default Field 1: " + defaultField1);
	        System.out.println("Default Field 2: " + defaultField2);
	    }
	}

	
