package AccessModifier;

public class publicmethod {

	    // Public fields
	    public int publicField1;
	    public String publicField2;

	    // Public constructor
	    public publicmethod(int publicField1, String publicField2) {
	        this.publicField1 = publicField1;
	        this.publicField2 = publicField2;
	    }

	    // Public method
	    public void publicMethod() {
	        System.out.println("Public Method Called");
	        System.out.println("Public Field 1: " + publicField1);
	        System.out.println("Public Field 2: " + publicField2);
	    }
	}

