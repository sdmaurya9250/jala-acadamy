package AccessModifier;

//Another class within the same package
public class subclass_ofdefault {

	
		
		    public static void main(String[] args) {
		        // Create an instance of DefaultExample
		    	defoultmethodconstructor example = new defoultmethodconstructor(20, "Default");

		        // Accessing default fields
		        System.out.println("Accessing default fields from AnotherClass:");
		        System.out.println("Default Field 1: " + example.defaultField1);
		        System.out.println("Default Field 2: " + example.defaultField2);

		        // Accessing default method
		        System.out.println("\nAccessing default method from AnotherClass:");
		        example.defaultMethod();
		    }
		}

