package Array;

public class Arraycontainstwospesificnum {

	// Method to verify if an array contains two specified elements
    static boolean containsElements(int[] array, int element1, int element2) {
        // Initialize flags to check if both elements are found
        boolean containsElement1 = false;
        boolean containsElement2 = false;

        // Iterate through the array to check for the specified elements
        for (int num : array) {
            if (num == element1) {
                containsElement1 = true;
            } else if (num == element2) {
                containsElement2 = true;
            }

            // Break the loop early if both elements are found
            if (containsElement1 && containsElement2) {
                break;
            }
        }

        // Return true if both elements are found, otherwise, return false
        return containsElement1 && containsElement2;
    }

    public static void main(String[] args) {
        // Example array
        int[] numbers = {10, 5, 8, 20, 15};

        // Elements to verify
        int element1 = 12;
        int element2 = 23;

        // Call the containsElements method
        boolean result = containsElements(numbers, element1, element2);

        // Print the original array and the verification result
        System.out.println("Array: " + java.util.Arrays.toString(numbers));
        System.out.println("Contains " + element1 + " and " + element2 + ": " + result);
    }
}