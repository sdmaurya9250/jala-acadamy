package Array;

import java.util.Arrays;

public class Copyanarray {


		// Function to copy an array to another array
	    static void copyArray(int[] sourceArray, int[] destinationArray) {
	        // Check if both arrays have the same length
	        if (sourceArray.length == destinationArray.length) {
	            // Using System.arraycopy
	            System.arraycopy(sourceArray, 0, destinationArray, 0, sourceArray.length);

	            // Alternatively, using a loop
	            // for (int i = 0; i < sourceArray.length; i++) {
	            //     destinationArray[i] = sourceArray[i];
	            // }
	        } else {
	            System.out.println("Arrays must have the same length for copying.");
	        }
	    }

	    public static void main(String[] args) {
	        // Example arrays
	        int[] sourceArray = {1, 2, 3, 4, 5};
	        int[] destinationArray = new int[sourceArray.length];

	        // Call the copyArray function
	        copyArray(sourceArray, destinationArray);

	        // Print the original and copied arrays
	        System.out.println("Source Array: " + Arrays.toString(sourceArray));
	        System.out.println("Destination Array (Copy): " + Arrays.toString(destinationArray));
	    }
	}