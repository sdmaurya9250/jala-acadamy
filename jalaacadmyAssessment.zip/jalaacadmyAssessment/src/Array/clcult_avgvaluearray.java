package Array;

public class clcult_avgvaluearray {

	 // Function to calculate the average value of an array of integers
    static double calculateArrayAverage(int[] array) {
        if (array.length == 0) {
            // Handle the case where the array is empty to avoid division by zero
            System.out.println("Error: Cannot calculate average for an empty array.");
            return 0.0;
        }

        int sum = 0;

        // Iterate through the array and add each element to the sum
        for (int element : array) {
            sum += element;
        }

        // Calculate the average by dividing the sum by the number of elements
        return (double) sum / array.length;
    }

    public static void main(String[] args) {
        // Example array
        int[] numbers = {1, 2, 3, 4, 5};

        // Call the calculateArrayAverage function
        double average = calculateArrayAverage(numbers);

        // Print the original array and the average
        System.out.println("Array: " + java.util.Arrays.toString(numbers));
        System.out.println("Average of Array Elements: " + average);
    }
}