package Array;

import java.util.HashSet;

public class commonvalueanarray {

	// Function to find common values between two arrays
    static void findCommonValues(int[] array1, int[] array2) {
        HashSet<Integer> set1 = new HashSet<>();
        HashSet<Integer> commonValues = new HashSet<>();

        // Add elements from the first array to set1
        for (int element : array1) {
            set1.add(element);
        }

        // Check elements in the second array against set1
        for (int element : array2) {
            if (set1.contains(element)) {
                commonValues.add(element);
            }
        }

        // Print the common values
        if (commonValues.isEmpty()) {
            System.out.println("No common values found.");
        } else {
            System.out.println("Common values: " + commonValues);
        }
    }

    public static void main(String[] args) {
        // Example arrays with common values
        int[] array1 = {1, 2, 3, 4, 5};
        int[] array2 = {3, 4, 5, 6, 7};

        // Call the findCommonValues function
        findCommonValues(array1, array2);
    }
}
