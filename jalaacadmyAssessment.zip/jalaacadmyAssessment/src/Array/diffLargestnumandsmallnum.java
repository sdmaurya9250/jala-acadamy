package Array;

public class diffLargestnumandsmallnum {

	// Function to get the difference between the largest and smallest values in an array
    static int getDifferenceLargestSmallest(int[] array) {
        if (array.length == 0) {
            System.out.println("Array is empty.");
            return -1; // Indicate an error or handle as needed
        }

        int smallest = array[0];
        int largest = array[0];

        // Find the smallest and largest values in the array
        for (int num : array) {
            if (num < smallest) {
                smallest = num;
            } else if (num > largest) {
                largest = num;
            }
        }

        // Calculate and return the difference
        return largest - smallest;
    }

    public static void main(String[] args) {
        // Example array
        int[] numbers = {10, 5, 8, 20, 15};

        // Call the getDifferenceLargestSmallest function
        int result = getDifferenceLargestSmallest(numbers);

        // Print the original array and the difference
        System.out.println("Array: " + java.util.Arrays.toString(numbers));
        System.out.println("Difference between Largest and Smallest: " + result);
    }
}
