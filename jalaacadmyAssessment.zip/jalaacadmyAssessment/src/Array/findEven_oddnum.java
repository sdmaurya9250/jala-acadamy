package Array;

public class findEven_oddnum {

	   // Method to find the number of even and odd numbers in an array
    static void countEvenOddNumbers(int[] array) {
        int evenCount = 0;
        int oddCount = 0;

        // Iterate through the array and count even and odd numbers
        for (int num : array) {
            if (num % 2 == 0) {
                evenCount++;
            } else {
                oddCount++;
            }
        }

        // Print the counts
        System.out.println("Number of Even Numbers: " + evenCount);
        System.out.println("Number of Odd Numbers: " + oddCount);
    }

    public static void main(String[] args) {
        // Example array
        int[] numbers = {10, 5, 8, 20, 15, 7};

        // Call the countEvenOddNumbers method
        countEvenOddNumbers(numbers);
    }
}