package Array;

import java.util.HashSet;

public class findduplicateanarray {

	// Function to find duplicate values in an array
    static void findDuplicates(int[] array) {
        HashSet<Integer> uniqueElements = new HashSet<>();
        HashSet<Integer> duplicateElements = new HashSet<>();

        for (int element : array) {
            // If the element is already in uniqueElements, it's a duplicate
            if (!uniqueElements.add(element)) {
                duplicateElements.add(element);
            }
        }

        // Print the duplicate elements
        if (duplicateElements.isEmpty()) {
            System.out.println("No duplicate elements found.");
        } else {
            System.out.println("Duplicate elements: " + duplicateElements);
        }
    }

    public static void main(String[] args) {
        // Example array with duplicates
        int[] numbers = {1, 2, 3, 4, 2, 5, 6, 3, 7, 8, 9, 1};

        // Call the findDuplicates function
        findDuplicates(numbers);
    }
}
