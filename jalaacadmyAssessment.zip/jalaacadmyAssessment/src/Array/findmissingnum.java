package Array;

public class findmissingnum {

	 // Function to find the missing number in a sorted array of 1 to 100
    static int findMissingNumber(int[] sortedArray) {
        int expectedSum = 0;
        int actualSum = 0;

        // Calculate the sum of the first 100 natural numbers (including the missing number)
        for (int i = 1; i <= 100; i++) {
            expectedSum += i;
        }

        // Calculate the sum of the actual elements in the array
        for (int num : sortedArray) {
            actualSum += num;
        }

        // The missing number is the difference between the expected and actual sums
        return expectedSum - actualSum;
    }

    public static void main(String[] args) {
        // Example sorted array with one missing number
        int[] sortedArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, /* Missing Number */ 12, 13, 14, 15, /* ... */ 100};

        // Call the findMissingNumber function
        int result = findMissingNumber(sortedArray);

        // Print the missing number
        System.out.println("Missing Number: " + result);
    }
}