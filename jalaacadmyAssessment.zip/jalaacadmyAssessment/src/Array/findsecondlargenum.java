package Array;

public class findsecondlargenum {

	// Method to find the second largest number in an array
    static int findSecondLargest(int[] array) {
        if (array.length < 2) {
            System.out.println("Array must have at least two elements.");
            return -1; // Indicate an error or handle as needed
        }

        int largest = Integer.MIN_VALUE;
        int secondLargest = Integer.MIN_VALUE;

        // Find the largest and second-largest numbers in the array
        for (int num : array) {
            if (num > largest) {
                secondLargest = largest;
                largest = num;
            } else if (num > secondLargest && num < largest) {
                secondLargest = num;
            }
        }

        return secondLargest;
    }

    public static void main(String[] args) {
        // Example array
        int[] numbers = {10, 5, 8, 20, 15};

        // Call the findSecondLargest method
        int result = findSecondLargest(numbers);

        // Print the original array and the second largest number
        System.out.println("Array: " + java.util.Arrays.toString(numbers));
        System.out.println("Second Largest Number: " + result);
    }
}