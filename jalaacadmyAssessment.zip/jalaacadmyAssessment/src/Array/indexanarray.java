package Array;
import java.util.Scanner;

public class indexanarray {

	// Function to find the index of an element in an array
    static int findElementIndex(int[] array, int target) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == target) {
                return i; // Return the index if the element is found
            }
        }
        return -1; // Return -1 if the element is not found in the array
    }

    public static void main(String[] args) {
        // Example array
        int[] numbers = {10, 20, 30, 40, 50};

        // Prompt the user to enter the element to find
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the element to find: ");
        int targetElement = scanner.nextInt();
        scanner.close();

        // Call the findElementIndex function
        int index = findElementIndex(numbers, targetElement);

        // Print the result
        if (index != -1) {
            System.out.println("Element " + targetElement + " found at index " + index);
        } else {
            System.out.println("Element " + targetElement + " not found in the array");
        }
    }
}