package Array;

import java.util.Arrays;

public class insertanElement {

	// Function to insert an element at a specific position in an array
    static int[] insertElementAtPosition(int[] array, int element, int position) {
        // Check if the position is valid
        if (position < 0 || position > array.length) {
            System.out.println("Invalid position. Element not inserted.");
            return array;
        }

        // Create a new array with increased size
        int[] newArray = new int[array.length + 1];

        // Copy elements before the specified position
        for (int i = 0; i < position; i++) {
            newArray[i] = array[i];
        }

        // Insert the new element at the specified position
        newArray[position] = element;

        // Copy elements after the specified position
        for (int i = position; i < array.length; i++) {
            newArray[i + 1] = array[i];
        }

        return newArray;
    }

    public static void main(String[] args) {
        // Example array
        int[] numbers = {10, 20, 30, 40, 50};

        // Element to insert
        int elementToInsert = 25;

        // Position to insert the element
        int insertPosition = 2;

        // Call the insertElementAtPosition function
        int[] resultArray = insertElementAtPosition(numbers, elementToInsert, insertPosition);

        // Print the original and modified arrays
        System.out.println("Original Array: " + Arrays.toString(numbers));
        System.out.println("Element " + elementToInsert + " inserted at position " + insertPosition + ": " +
                Arrays.toString(resultArray));
    }
}
