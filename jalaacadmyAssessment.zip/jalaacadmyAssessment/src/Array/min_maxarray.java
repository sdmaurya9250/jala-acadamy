package Array;

public class min_maxarray {

	// Function to find the minimum and maximum values of an array
    static void findMinMax(int[] array) {
        // Check if the array is not empty
        if (array.length == 0) {
            System.out.println("Array is empty.");
            return;
        }

        int min = array[0];  // Assume the first element as the initial minimum
        int max = array[0];  // Assume the first element as the initial maximum

        // Iterate through the array to find the minimum and maximum values
        for (int i = 1; i < array.length; i++) {
            if (array[i] < min) {
                min = array[i];  // Update the minimum value
            } else if (array[i] > max) {
                max = array[i];  // Update the maximum value
            }
        }

        // Print the minimum and maximum values
        System.out.println("Minimum value: " + min);
        System.out.println("Maximum value: " + max);
    }

    public static void main(String[] args) {
        // Example array
        int[] numbers = {15, 7, 23, 45, 8, 10};

        // Call the findMinMax function
        findMinMax(numbers);
    }
}