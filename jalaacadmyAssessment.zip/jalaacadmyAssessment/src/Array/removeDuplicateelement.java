package Array;

import java.util.Arrays;
import java.util.HashSet;

public class removeDuplicateelement {

	// Method to remove duplicate elements from an array
    static int[] removeDuplicates(int[] array) {
        HashSet<Integer> uniqueElements = new HashSet<>();
        for (int element : array) {
            uniqueElements.add(element);
        }

        // Convert the HashSet back to an array
        int[] resultArray = new int[uniqueElements.size()];
        int index = 0;
        for (int element : uniqueElements) {
            resultArray[index++] = element;
        }

        return resultArray;
    }

    public static void main(String[] args) {
        // Example array with duplicates
        int[] numbers = {1, 2, 3, 4, 2, 5, 6, 3, 7, 8, 9, 1};

        // Call the removeDuplicates method
        int[] resultArray = removeDuplicates(numbers);

        // Print the original and modified arrays
        System.out.println("Original Array: " + Arrays.toString(numbers));
        System.out.println("Array with Duplicates Removed: " + Arrays.toString(resultArray));
    }
}
