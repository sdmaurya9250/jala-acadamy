package Array;

import java.util.Arrays;
import java.util.HashSet;

public class removeduplicate_returnnewarray {

	// Function to remove duplicate elements from an array and return a new array
    static int[] removeDuplicates(int[] array) {
        HashSet<Integer> uniqueElements = new HashSet<>();
        
        // Add unique elements to the HashSet
        for (int element : array) {
            uniqueElements.add(element);
        }

        // Convert the HashSet back to an array
        int[] resultArray = new int[uniqueElements.size()];
        int index = 0;
        for (int element : uniqueElements) {
            resultArray[index++] = element;
        }

        return resultArray;
    }

    public static void main(String[] args) {
        // Example array with duplicates
        int[] numbers = {1, 2, 3, 4, 2, 5, 6, 3, 7, 8, 9, 1};

        // Call the removeDuplicates function
        int[] resultArray = removeDuplicates(numbers);

        // Print the original and modified arrays
        System.out.println("Original Array: " + Arrays.toString(numbers));
        System.out.println("Array with Duplicates Removed: " + Arrays.toString(resultArray));
    }
}
