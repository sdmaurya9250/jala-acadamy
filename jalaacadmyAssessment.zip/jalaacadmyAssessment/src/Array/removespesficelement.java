package Array;

import java.util.ArrayList;
import java.util.Arrays;

public class removespesficelement {


	// Function to remove a specific element from an array
    static int[] removeElementFromArray(int[] array, int target) {
        ArrayList<Integer> arrayList = new ArrayList<>();
        for (int element : array) {
            if (element != target) {
                arrayList.add(element);
            }
        }

        // Convert the ArrayList back to an array
        int[] resultArray = new int[arrayList.size()];
        for (int i = 0; i < arrayList.size(); i++) {
            resultArray[i] = arrayList.get(i);
        }

        return resultArray;
    }

    public static void main(String[] args) {
        // Example array
        int[] numbers = {10, 20, 30, 40, 50};

        // Element to remove
        int targetElement = 30;

        // Call the removeElementFromArray function
        int[] resultArray = removeElementFromArray(numbers, targetElement);

        // Print the original and modified arrays
        System.out.println("Original Array: " + Arrays.toString(numbers));
        System.out.println("Element " + targetElement + " removed: " + Arrays.toString(resultArray));
    }
}