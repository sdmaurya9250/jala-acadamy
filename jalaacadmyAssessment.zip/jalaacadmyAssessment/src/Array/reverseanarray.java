package Array;

import java.util.Arrays;

public class reverseanarray {

	// Function to reverse an array of integers
    static void reverseArray(int[] array) {
        int start = 0;
        int end = array.length - 1;

        // Swap elements from the start and end of the array until they meet in the middle
        while (start < end) {
            // Swap elements at start and end positions
            int temp = array[start];
            array[start] = array[end];
            array[end] = temp;

            // Move to the next pair of elements
            start++;
            end--;
        }
    }

    public static void main(String[] args) {
        // Example array
        int[] numbers = {1, 2, 3, 4, 5};

        // Call the reverseArray function
        reverseArray(numbers);

        // Print the original and reversed arrays
        System.out.println("Original Array: " + Arrays.toString(numbers));
        System.out.println("Reversed Array: " + Arrays.toString(numbers));
    }
}
