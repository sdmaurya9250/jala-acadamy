package Method_Overloading;

public class demo2 {

	    public static void main(String[] args) {
	        MethodOverloadingExample obj = new MethodOverloadingExample();

	        // Calling the first method
	        obj.display(10);

	        // Calling the second method
	        obj.display("Hello", 5);
	    }

	    // First method with one parameter of type int
	    public void display(int number) {
	        System.out.println("Displaying number: " + number);
	    }

	    // Second method with two parameters of different types, String and int
	    public void display(String message, int count) {
	        for (int i = 0; i < count; i++) {
	            System.out.println("Displaying message " + (i + 1) + ": " + message);
	        }
	    }

}
