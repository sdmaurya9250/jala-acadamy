package Method_Overloading;

public class demo3 {

	    public static void main(String[] args) {
	        MethodOverloadingExample obj = new MethodOverloadingExample();

	        // Call the methods with different parameters
	        obj.display(10);
	        obj.display("Hello");
	    }

	    // Method with one parameter of type int
	    public void display(int number) {
	        System.out.println("Displaying number: " + number);
	    }

	    // Method with one parameter of type String
	    public void display(String message) {
	        System.out.println("Displaying message: " + message);
	    }
	}

