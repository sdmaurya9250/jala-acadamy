package Method_Overloading;

public class demo4 {

	    public static void main(String[] args) {
	        MethodOverloadingExample obj = new MethodOverloadingExample();

	        // Call the methods with different parameter types
	        obj.display("Hello", 5);
	        obj.display(10, "World");
	    }

	    // Method with two parameters of type String and int
	    public void display(String message, int count) {
	        for (int i = 0; i < count; i++) {
	            System.out.println("Displaying message " + (i + 1) + ": " + message);
	        }
	    }

	    // Method with two parameters of type int and String
	    public void display(int count, String message) {
	        for (int i = 0; i < count; i++) {
	            System.out.println("Displaying message " + (i + 1) + ": " + message);
	        }
	    }
	}

