package Method_Overloading;

public class demo5 {

	    public static void main(String[] args) {
	        MethodOverloadingExample obj = new MethodOverloadingExample();

	        // Call the methods with the same name and parameters but different return types
	        int result1 = obj.add(5, 3);
	        String result2 = obj.add("Hello", "World");

	        System.out.println("Result of int add: " + result1);
	        System.out.println("Result of String add: " + result2);
	    }

	    // Method returning int
	    public int add(int a, int b) {
	        return a + b;
	    }

	    // Method returning String
	    public String add(String str1, String str2) {
	        return str1 + " " + str2;
	    }
	}

