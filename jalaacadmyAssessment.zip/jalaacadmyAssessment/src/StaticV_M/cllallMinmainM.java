package StaticV_M;

public class cllallMinmainM {

	 // Static method
    static void staticMethod() {
        System.out.println("Static Method called.");
    }

    // Instance method
    void instanceMethod() {
        System.out.println("Instance Method called.");
    }

    public static void main(String[] args) {
        // Call static method directly using the class name
        staticMethod();

        // Create an instance of ExampleClass
        ExampleClass exampleInstance = new ExampleClass();

        // Call instance method through the instance
        exampleInstance.instanceMethod();
    }
}
