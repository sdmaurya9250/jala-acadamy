package StaticV_M;

public class instanceMinstaticM {

	    // Instance method
	    void instanceMethod() {
	        System.out.println("Instance Method called.");
	    }

	    // Static method calling instance method with a new instance
	    static void staticMethod1() {
	        ExampleClass instance = new ExampleClass();
	        instance.instanceMethod();
	        System.out.println("Static Method 1 called.");
	    }

	    // Static method calling instance method with an instance passed as a parameter
	    static void staticMethod2(ExampleClass instance) {
	        instance.instanceMethod();
	        System.out.println("Static Method 2 called.");
	    }

	    public static void main(String[] args) {
	        // Create an instance of ExampleClass
	        ExampleClass exampleInstance = new ExampleClass();

	        // Call instance methods from static methods
	        staticMethod1();
	        staticMethod2(exampleInstance);
	    }
	}
