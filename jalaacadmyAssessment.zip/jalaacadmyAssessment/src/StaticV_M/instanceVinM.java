package StaticV_M;

public class instanceVinM {

	 // Instance variables
    int instanceVar1;
    String instanceVar2;

    // Static method accessing instance variables through an instance
    static void staticMethod1() {
        ExampleClass instance = new ExampleClass();
        instance.instanceVar1 = 5;
        instance.instanceVar2 = "Accessed in staticMethod1";
        System.out.println("Static Method 1 accessing instance variables:");
        System.out.println("Instance Variable 1: " + instance.instanceVar1);
        System.out.println("Instance Variable 2: " + instance.instanceVar2);
    }

    // Static method accessing instance variables with static variables
    static void staticMethod2() {
        System.out.println("Static Method 2 accessing instance variables with static variables:");
        System.out.println("Instance Variable 1: " + staticVar1);
        System.out.println("Instance Variable 2: " + staticVar2);
    }

    // Static variables
    static int staticVar1;
    static String staticVar2;

    public static void main(String[] args) {
        // Accessing instance variables in static methods
        staticMethod1();
        staticMethod2();
    }
}
