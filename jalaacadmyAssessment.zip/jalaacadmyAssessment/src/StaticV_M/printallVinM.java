package StaticV_M;

public class printallVinM {

	// Static variables
    static int staticVar1 = 10;
    static String staticVar2 = "Static Variable";

    // Instance variables
    int instanceVar1 = 20;
    String instanceVar2 = "Instance Variable";

    // Static method
    static void staticMethod() {
        System.out.println("Static Method called.");
    }

    // Instance method
    void instanceMethod() {
        System.out.println("Instance Method called.");
    }

    public static void main(String[] args) {
        // Accessing static variables directly
        System.out.println("Static Variable 1 in main: " + staticVar1);
        System.out.println("Static Variable 2 in main: " + staticVar2);

        // Creating an instance of ExampleClass
        ExampleClass exampleInstance = new ExampleClass();

        // Accessing instance variables through the instance
        System.out.println("Instance Variable 1 in main: " + exampleInstance.instanceVar1);
        System.out.println("Instance Variable 2 in main: " + exampleInstance.instanceVar2);

        // Calling static method
        staticMethod();

        // Calling instance method through the instance
        exampleInstance.instanceMethod();
    }
}