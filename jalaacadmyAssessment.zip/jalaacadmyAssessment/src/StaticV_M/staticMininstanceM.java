package StaticV_M;

public class staticMininstanceM {

	// Static method
    static void staticMethod() {
        System.out.println("Static Method called.");
    }

    // Instance method calling static method
    void instanceMethod() {
        System.out.println("Instance Method called.");
        
        // Call the static method from the instance method
        staticMethod();
    }

    public static void main(String[] args) {
        // Create an instance of ExampleClass
        ExampleClass exampleInstance = new ExampleClass();

        // Call the instance method, which in turn calls the static method
        exampleInstance.instanceMethod();
    }
}