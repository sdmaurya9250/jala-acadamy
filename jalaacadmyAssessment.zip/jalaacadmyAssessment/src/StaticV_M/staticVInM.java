package StaticV_M;

public class staticVInM {

		// Static variables
	    static int staticVar1 = 10;
	    static String staticVar2 = "Static Variable";

	    // Instance method accessing static variables using the class name
	    void instanceMethod1() {
	        System.out.println("Instance Method 1 accessing static variables using class name:");
	        System.out.println("Static Variable 1: " + ExampleClass.staticVar1);
	        System.out.println("Static Variable 2: " + ExampleClass.staticVar2);
	    }

	    // Instance method accessing static variables directly
	    void instanceMethod2() {
	        System.out.println("Instance Method 2 accessing static variables directly:");
	        System.out.println("Static Variable 1: " + staticVar1);
	        System.out.println("Static Variable 2: " + staticVar2);
	    }

	    public static void main(String[] args) {
	        // Create an instance of ExampleClass
	        ExampleClass instance = new ExampleClass();

	        // Accessing static variables in instance methods
	        instance.instanceMethod1();
	        instance.instanceMethod2();
	    }
	}