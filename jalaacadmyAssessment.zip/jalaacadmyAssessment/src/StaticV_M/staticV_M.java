package StaticV_M;

public class staticV_M {

	public static void main(String[] args) {

		 // Static variables
	    static int staticVar1;
	    static String staticVar2;

	    // Instance variables
	    int instanceVar1;
	    String instanceVar2;

	    // Static methods
	    static void staticMethod1() {
	        System.out.println("Static Method 1 called.");
	    }

	    static void staticMethod2() {
	        System.out.println("Static Method 2 called.");
	    }

	    // Instance methods
	    void instanceMethod1() {
	        System.out.println("Instance Method 1 called.");
	    }

	    void instanceMethod2() {
	        System.out.println("Instance Method 2 called.");
	    }

	    // Main method
	    public static void main(String[] args) {
	        // Accessing static variables and methods
	        staticVar1 = 10;
	        staticVar2 = "Hello, Static!";

	        System.out.println("Static Variable 1: " + staticVar1);
	        System.out.println("Static Variable 2: " + staticVar2);

	        staticMethod1();
	        staticMethod2();

	       
	        // Creating an instance of the class
	        ExampleClass exampleObject = new ExampleClass();

	        // Accessing instance variables and methods
	        exampleObject.instanceVar1 = 5;
	        exampleObject.instanceVar2 = "Hello, Instance!";

	        System.out.println("Instance Variable 1: " + exampleObject.instanceVar1);
	        System.out.println("Instance Variable 2: " + exampleObject.instanceVar2);

	        exampleObject.instanceMethod1();
	        exampleObject.instanceMethod2();
	    }
	}
	