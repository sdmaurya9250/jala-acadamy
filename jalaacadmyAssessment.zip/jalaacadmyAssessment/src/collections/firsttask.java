package collections;

import java.util.ArrayList;
import java.util.Iterator;

public class firsttask {
	

	public static void main(String[] args) {
		
		

		
		        // Create an ArrayList of type String with 10 string elements
		        ArrayList<String> arrayList = new ArrayList<>(10);

		        // Add 10 string elements to ArrayList
		        for (int i = 0; i < 10; i++) {
		            arrayList.add("Element " + i);
		        }

		        // Add an element to the ArrayList
		        arrayList.add("New Element");

		        // Iterate through the ArrayList using Iterator object
		        Iterator<String> iterator = arrayList.iterator();
		        while (iterator.hasNext()) {
		            System.out.println(iterator.next());
		        }

		        // Add an element at a specific index
		        arrayList.add(5, "Inserted Element");

		        // Remove an element from the ArrayList, Remove at an index
		        arrayList.remove("Element 2");
		        arrayList.remove(7);

		        // Update the element at a specific index
		        arrayList.set(3, "Updated Element");

		        // Check if the element is present at a particular index
		        int indexToCheck = 4;
		        if (indexToCheck < arrayList.size()) {
		            System.out.println("Element at index " + indexToCheck + ": " + arrayList.get(indexToCheck));
		        } else {
		            System.out.println("Index out of bounds.");
		        }

		        // Find out the size of the ArrayList
		        System.out.println("Size of the ArrayList: " + arrayList.size());

		        // Check if the given element is present in the ArrayList
		        String elementToCheck = "Element 5";
		        if (arrayList.contains(elementToCheck)) {
		            System.out.println(elementToCheck + " is present in the ArrayList.");
		        } else {
		            System.out.println(elementToCheck + " is not present in the ArrayList.");
		        }

		        // Remove all elements of the ArrayList
		        arrayList.clear();
		        System.out.println("All elements removed. Size of the ArrayList now: " + arrayList.size());
		    }
		}

