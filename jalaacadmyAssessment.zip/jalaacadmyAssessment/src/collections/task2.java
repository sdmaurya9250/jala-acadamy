package collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class task2 {

	    public static void main(String[] args) {
	        // Create a HashMap with at least 10 key-value pairs of Student ID and Name
	        Map<Integer, String> studentMap = new HashMap<>();
	        studentMap.put(1, "John");
	        studentMap.put(2, "Alice");
	        studentMap.put(3, "Bob");
	        studentMap.put(4, "Emily");
	        studentMap.put(5, "David");
	        studentMap.put(6, "Sophia");
	        studentMap.put(7, "Michael");
	        studentMap.put(8, "Emma");
	        studentMap.put(9, "Daniel");
	        studentMap.put(10, "Olivia");

	        // Insert a Key value mapping into the map
	        studentMap.put(11, "Liam");

	        // Fetch the value of a Key
	        int keyToFetch = 5;
	        String value = studentMap.get(keyToFetch);
	        System.out.println("Value for key " + keyToFetch + ": " + value);

	        // Create a clone/copy of HashMap
	        Map<Integer, String> cloneMap = new HashMap<>(studentMap);

	        // Check if the given Key is in the Map
	        int keyToCheck = 7;
	        System.out.println("Is key " + keyToCheck + " present in the map? " + studentMap.containsKey(keyToCheck));

	        // Check if the value is in the Map
	        String valueToCheck = "Sophia";
	        System.out.println("Is value \"" + valueToCheck + "\" present in the map? " + studentMap.containsValue(valueToCheck));

	        // Check if the map is empty
	        System.out.println("Is the map empty? " + studentMap.isEmpty());

	        // Print the size of the Map to the console
	        System.out.println("Size of the map: " + studentMap.size());

	        // Print all the Keys of the map to the console
	        System.out.println("Keys of the map:");
	        Set<Integer> keys = studentMap.keySet();
	        for (Integer key : keys) {
	            System.out.println(key);
	        }

	        // Remove a specific Key-value pair
	        int keyToRemove = 3;
	        studentMap.remove(keyToRemove);
	        System.out.println("Removed key-value pair with key " + keyToRemove);

	        // Copy all the elements of the Map to another Map
	        Map<Integer, String> anotherMap = new HashMap<>(studentMap);
	        System.out.println("Copied all elements to another map.");
	    }
	}

