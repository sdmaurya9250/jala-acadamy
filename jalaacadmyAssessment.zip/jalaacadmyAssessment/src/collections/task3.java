package collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class task3 {

	    public static void main(String[] args) {
	        // Create a HashSet with at least 10 elements of type String
	        Set<String> hashSet = new HashSet<>();
	        hashSet.add("Apple");
	        hashSet.add("Banana");
	        hashSet.add("Orange");
	        hashSet.add("Grapes");
	        hashSet.add("Mango");
	        hashSet.add("Pineapple");
	        hashSet.add("Watermelon");
	        hashSet.add("Strawberry");
	        hashSet.add("Peach");
	        hashSet.add("Kiwi");

	        // Display the HashSet
	        System.out.println("HashSet: " + hashSet);

	        // Add an element to the HashSet
	        hashSet.add("Pear");
	        System.out.println("After adding 'Pear': " + hashSet);

	        // Iterate through the HashSet using Iterator
	        Iterator<String> iterator = hashSet.iterator();
	        System.out.println("HashSet elements using iterator:");
	        while (iterator.hasNext()) {
	            System.out.println(iterator.next());
	        }

	        // Check if an element is present in the HashSet
	        String elementToCheck = "Orange";
	        System.out.println("Is '" + elementToCheck + "' present in the HashSet? " + hashSet.contains(elementToCheck));

	        // Remove an element from the HashSet
	        String elementToRemove = "Pineapple";
	        hashSet.remove(elementToRemove);
	        System.out.println("After removing '" + elementToRemove + "': " + hashSet);

	        // Check if the HashSet is empty
	        System.out.println("Is the HashSet empty? " + hashSet.isEmpty());

	        // Print the size of the HashSet
	        System.out.println("Size of the HashSet: " + hashSet.size());

	        // Remove all elements from the HashSet
	        hashSet.clear();
	        System.out.println("HashSet after clearing: " + hashSet);
	    }
	}

