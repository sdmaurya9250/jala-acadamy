package cunnstructor;

public class applyAllModifier_toConstructor {

	
	    // Public constructor
	    public applyAllModifier_toConstructor() {
	        // Constructor logic
	    }
	}

}
