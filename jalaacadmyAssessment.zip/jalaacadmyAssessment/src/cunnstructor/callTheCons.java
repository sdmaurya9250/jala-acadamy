package cunnstructor;

public class callTheCons {

}
