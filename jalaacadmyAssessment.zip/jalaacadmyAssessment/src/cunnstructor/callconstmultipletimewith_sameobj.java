package cunnstructor;

public class callconstmultipletimewith_sameobj {

	    private int intValue;
	    private String stringValue;

	    // Constructor with int return type
	    public callconstmultipletimewith_sameobj(int intValue, String stringValue) {
	        this.intValue = intValue;
	        this.stringValue = stringValue;
	    }

	    public void displayValues() {
	        System.out.println("Int value: " + intValue);
	        System.out.println("String value: " + stringValue);
	    }

	    public static void main(String[] args) {
	        // Creating the first object
	    	callconstmultipletimewith_sameobj example1 = new callconstmultipletimewith_sameobj(42, "Hello");

	        // Calling the displayValues method on the first object
	        System.out.println("Values of example1:");
	        example1.displayValues();

	        // Creating the second object
	        callconstmultipletimewith_sameobj example2 = new callconstmultipletimewith_sameobj(100, "World");

	        // Calling the displayValues method on the second object
	        System.out.println("\nValues of example2:");
	        example2.displayValues();
	    }
	}

public class stringconst {
	    private String stringValue;

	    // Constructor with String return type
	    public stringconst(String value) {
	        this.stringValue = value;
	    }

	    public String getStringValue() {
	        return stringValue;
	    }

	    public static void main(String[] args) {
	    	stringconst example = new stringconst("Hello, World!");
	        System.out.println("String value: " + example.getStringValue());
	    }
	}
