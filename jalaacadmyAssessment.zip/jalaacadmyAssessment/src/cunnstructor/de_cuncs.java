package cunnstructor;

public class de_cuncs {

}
