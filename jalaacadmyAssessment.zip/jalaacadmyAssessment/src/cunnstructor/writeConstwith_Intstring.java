package cunnstructor;

public class writeConstwith_Intstring {

	    private int intValue;

	    // Constructor with int return type
	    public writeConstwith_Intstring(int value) {
	        this.intValue = value;
	    }

	    public int getIntValue() {
	        return intValue;
	    }

	    public static void main(String[] args) {
	    	writeConstwith_Intstring example = new writeConstwith_Intstring(42);
	        System.out.println("Int value: " + example.getIntValue());
	    }
	}
