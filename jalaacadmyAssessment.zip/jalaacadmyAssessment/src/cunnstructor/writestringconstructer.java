package cunnstructor;

public class writestringconstructer {

	    private String stringValue;

	    // Constructor with String return type
	    public writestringconstructer(String value) {
	        this.stringValue = value;
	    }

	    public String getStringValue() {
	        return stringValue;
	    }

	    public static void main(String[] args) {
	    	writestringconstructer example = new writestringconstructer("Hello, World!");
	        System.out.println("String value: " + example.getStringValue());
	    }
	}

