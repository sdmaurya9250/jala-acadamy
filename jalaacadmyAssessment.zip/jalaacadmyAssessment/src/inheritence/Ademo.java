package inheritence;

public class Ademo {

	    private int aVar;

	    public void methodA1() {
	        System.out.println("Method A1 in class A");
	    }

	    public void methodA2() {
	        System.out.println("Method A2 in class A");
	    }

	    public void overrideMethod() {
	        System.out.println("Override Method in class A");
	    }

		public String getAVar() {
			// TODO Auto-generated method stub
			return null;
		}
	}

	

	

