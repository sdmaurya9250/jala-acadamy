package inheritence;

public class Bdemo extends  Ademo {

	
	    private int bVar;

	    @Override
	    public void methodA2() {
	        System.out.println("Method A2 overridden in class B");
	    }

	    public void methodB1() {
	        System.out.println("Method B1 in class B");
	    }

	    @Override
	    public void overrideMethod() {
	        System.out.println("Override Method in class B");
	    }

		@Override
		public void methodA1() {
			// TODO Auto-generated method stub
			
		}
	}

