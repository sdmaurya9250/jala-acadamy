package inheritence;

public class demo extends Bdemo{

	
	    private int cVar;

	    public void methodC1() {
	        System.out.println("Method C1 in class C");
	    }

	    public void methodC2() {
	        System.out.println("Method C2 in class C");
	    }

	    @Override
	    public void overrideMethod() {
	        System.out.println("Override Method in class C");
	    }
	}

	public class Main {
	    public static void main(String[] args) {
	        // Creating objects for each class
	        Ademo objA = new Ademo();
	        Bdemo objB = new Bdemo();
	        demo objC = new demo();

	        // Calling methods of each class using its own object
	        objA.methodA1();
	        objA.methodA2();
	        objA.overrideMethod();

	        objB.methodA1();  // Accessing method of superclass
	        objB.methodA2();
	        objB.methodB1();
	        objB.overrideMethod();  // Call overridden method in class B

	        objC.methodA1();  // Accessing method of superclass
	        objC.methodA2();  // Accessing overridden method in class B
	        objC.methodB1();  // Accessing method of superclass
	        objC.methodC1();
	        objC.methodC2();
	        objC.overrideMethod();  // Call overridden method in class C

	        // Runtime Polymorphism with data members
	        System.out.println("Data member in class A: " + objA.getAVar());

	        Bdemo polymorphicObjB = new Bdemo();
	        System.out.println("Data member in class A via B: " + ((Bdemo) polymorphicObjB).getAVar());
	        System.out.println("Data member in class B: " + ((Bdemo) polymorphicObjB).getBVar());

	        Ademo polymorphicObjC = new demo();
	        System.out.println("Data member in class A via C: " + ((demo) polymorphicObjC).getAVar());
	        System.out.println("Data member in class B via C: " + ((demo) polymorphicObjC).getBVar());
	        System.out.println("Data member in class C: " + ((demo) polymorphicObjC).getCVar());
	    }
	}
