package jalaacadmyAssessment;

public class basicAssassmnt {
	
	// Function to print your name
    private static void printMyName() {
        String myName = "Sakshi"; // Replace with your actual name
        System.out.println("My name is: " + myName);
    }

	// Main method (entry point of the program)
	public static void main(String[] args) {
		
		printMyName();
		
		
		int a =12;
		double b = 5000;
		boolean c = true;
        char d = 'A';
        float floatValue = 3.14f;
        double doubleValue = 2.71828;
		
		 System.out.println("This is a static method." +a);
		 System.out.println("This is a static method." + b);
		 System.out.println("This is a static method."+c);
		 System.out.println("This is a static method."+d); 
	        System.out.println("This is a static method."+floatValue);
	        System.out.println("This is a static method."+doubleValue);

	        
	}

}
