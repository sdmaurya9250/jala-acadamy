package jalaacadmyAssessment;

public class variabels {

	

		// Class-level (instance) variable
	    private int globalVariable = 10;

	    public static void main(String[] args) {
	    	
	        // Create an instance of the class
	         exampleInstance = new ScopeExample();

	        // Access and print both local and instance variables
	        exampleInstance.methodWithSameName();
	    }

	    // Method that uses the same variable name
	    private void methodWithSameName() {
	        // Local variable with the same name
	        int globalVariable = 5;

	        // Access and print the local variable within this method
	        System.out.println("Local variable in methodWithSameName: " + globalVariable);

	        // Access and print the instance variable within this method
	        System.out.println("Instance variable in methodWithSameName: " + this.globalVariable);
	   

	}

}
