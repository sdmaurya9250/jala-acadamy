package loops;

import java.util.Scanner;

public class Armstrongnum {

	public static void main(String[] args) {

		 // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a number
        System.out.print("Enter a number to check if it's an Armstrong number: ");
        int number = scanner.nextInt();

        // Close the Scanner to prevent resource leak
        scanner.close();

        // Check if the entered number is an Armstrong number
        if (isArmstrongNumber(number)) {
            System.out.println(number + " is an Armstrong number.");
        } else {
            System.out.println(number + " is not an Armstrong number.");
        }
    }

    // Function to check if a number is an Armstrong number
    private static boolean isArmstrongNumber(int num) {
        int originalNumber, remainder, result = 0, n = 0;

        // Assign the entered number to originalNumber
        originalNumber = num;

        // Count the number of digits in the entered number
        while (originalNumber != 0) {
            originalNumber /= 10;
            ++n;
        }

        originalNumber = num; // Reset originalNumber to the entered number

        // Calculate the sum of each digit raised to the power of the number of digits
        while (originalNumber != 0) {
            remainder = originalNumber % 10;
            result += Math.pow(remainder, n);
            originalNumber /= 10;
        }

        // Check if the result is equal to the entered number
        return result == num;
    }
}