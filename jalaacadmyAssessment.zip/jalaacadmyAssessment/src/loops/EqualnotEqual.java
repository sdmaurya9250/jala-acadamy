package loops;

public class EqualnotEqual {

	public static void main(String[] args) {

		// Using a for loop to compare equal and not equal operators for a range of numbers
        System.out.println("Equal Operator (==):");

        for (int i = 1; i <= 5; i++) {
            if (i == 3) {
                System.out.println(i + " is equal to 3");
            } else {
                System.out.println(i + " is not equal to 3");
            }
        }

        System.out.println("\nNot Equal Operator (!=):");

        for (int i = 1; i <= 5; i++) {
            if (i != 3) {
                System.out.println(i + " is not equal to 3");
            } else {
                System.out.println(i + " is equal to 3");
            }
        }
    }
}

