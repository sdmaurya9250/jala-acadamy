package loops;

public class EvenOdd {

	public static void main(String[] args) {

		 // Print even numbers from 1 to 20
        System.out.println("Even Numbers:");

        for (int i = 1; i <= 20; i++) {
            if (i % 2 == 0) {
                System.out.println(i);
            }
        }

        // Print odd numbers from 1 to 20
        System.out.println("\nOdd Numbers:");

        for (int i = 1; i <= 20; i++) {
            if (i % 2 != 0) {
                System.out.println(i);
            }
        }
    }
}