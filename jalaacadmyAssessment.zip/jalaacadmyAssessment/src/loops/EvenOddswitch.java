package loops;

import java.util.Scanner;

public class EvenOddswitch {

	public static void main(String[] args) {

		// Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a number
        System.out.print("Enter a number to check if it's even or odd: ");
        int number = scanner.nextInt();

        // Close the Scanner to prevent resource leak
        scanner.close();

        // Check if the entered number is even or odd using a switch statement
        switch (number % 2) {
            case 0:
                System.out.println(number + " is an even number.");
                break;
            case 1:
                System.out.println(number + " is an odd number.");
                break;
            default:
                System.out.println("Invalid input.");
        }
    }
}