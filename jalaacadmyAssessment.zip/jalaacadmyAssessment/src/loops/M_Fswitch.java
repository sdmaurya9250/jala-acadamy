package loops;

import java.util.Scanner;

public class M_Fswitch {

	public static void main(String[] args) {

		// Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a gender (M/F)
        System.out.print("Enter the gender (M/F): ");
        String gender = scanner.next().toUpperCase(); // Convert input to uppercase for case-insensitivity

        // Close the Scanner to prevent resource leak
        scanner.close();

        // Print the corresponding gender using a switch statement
        switch (gender) {
            case "M":
                System.out.println("Gender: Male");
                break;
            case "F":
                System.out.println("Gender: Female");
                break;
            default:
                System.out.println("Invalid gender input.");
        }
    }
}