package loops;

public class basic {

	public static void main(String[] args) {
		
		        // Using a for loop to print the message ten times
		        for (int i = 1; i <= 10; i++) {
		            System.out.println("Bright IT Career");
		            
		        }

		    }
		}