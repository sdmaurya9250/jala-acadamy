package loops;

public class doWhile1_10 {

	public static void main(String[] args) {

		 // Using a do-while loop to print numbers from 1 to 10
        int number = 1;

        System.out.println("Numbers from 1 to 10 using do-while loop:");

        do {
            System.out.println(number);
            number++;
        } while (number <= 10);
    }
}