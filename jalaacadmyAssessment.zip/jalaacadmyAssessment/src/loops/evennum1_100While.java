package loops;

public class evennum1_100While {

	public static void main(String[] args) {

		// Using a while loop to print even numbers between 10 and 100
        int number = 10;

        System.out.println("Even Numbers between 10 and 100:");

        while (number <= 100) {
            if (number % 2 == 0) {
                System.out.println(number);
            }
            number++;
        }
    }
}
