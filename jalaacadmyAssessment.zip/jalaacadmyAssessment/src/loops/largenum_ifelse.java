package loops;

public class largenum_ifelse {

	public static void main(String[] args) {

		 // Example numbers
        int num1 = 10;
        int num2 = 20;
        int num3 = 30;

        // Find the largest number using multiple if-else statements
        if (num1 >= num2 && num1 >= num3) {
            System.out.println("The largest number is: " + num1);
        } else if (num2 >= num1 && num2 >= num3) {
            System.out.println("The largest number is: " + num2);
        } else {
            System.out.println("The largest number is: " + num3);
        }
    }
}

