package loops;

public class largenumbetw3num {

	public static void main(String[] args) {

		 // Example numbers
        int number1 = 15;
        int number2 = 8;
        int number3 = 20;

        // Find the largest number
        int largestNumber = number1;

        if (number2 > largestNumber) {
            largestNumber = number2;
        }

        if (number3 > largestNumber) {
            largestNumber = number3;
        }

        // Print the result
        System.out.println("The largest number is: " + largestNumber);
    }
}