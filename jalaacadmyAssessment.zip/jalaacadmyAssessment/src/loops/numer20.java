package loops;

public class numer20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		   // Using a while loop to print numbers from 1 to 20
        int i = 1;

        while (i <= 20) {
            System.out.println(i);
            i++;
        }
	}

}
