package loops;

import java.util.Scanner;

public class polindromenum {

	public static void main(String[] args) {


		 // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a number or string
        System.out.print("Enter a number or string to check if it's a palindrome: ");
        String input = scanner.nextLine();

        // Close the Scanner to prevent resource leak
        scanner.close();

        // Check if the entered input is a palindrome
        if (isPalindrome(input)) {
            System.out.println("\"" + input + "\" is a palindrome.");
        } else {
            System.out.println("\"" + input + "\" is not a palindrome.");
        }
    }

    // Function to check if a string is a palindrome
    private static boolean isPalindrome(String str) {
        // Remove non-alphanumeric characters and convert to lowercase
        String cleanStr = str.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();

        // Compare the original string with its reverse
        return cleanStr.equals(new StringBuilder(cleanStr).reverse().toString());
    }
}