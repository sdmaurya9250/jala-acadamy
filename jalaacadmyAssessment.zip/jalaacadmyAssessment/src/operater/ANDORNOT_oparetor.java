package operater;

public class ANDORNOT_oparetor {

	public static void main(String[] args) {

//NOT OPARETOR
		 // Example variable
        boolean condition = true;

        // Logical NOT operator (!)
        if (!condition) {
            System.out.println("The condition is false.");
        } else {
            System.out.println("The condition is true.");
        }
 
        
//AND OPARETOR        

       // Example variables
        int number1 = 5;
       int number2 = 10;

// Logical AND operator (&&)
if (number1 > 0 && number2 < 20) {
    System.out.println("Both conditions are true.");
} else {
    System.out.println("At least one condition is false.");
}


//OR OPARETOR
   //Example variables
   int num1 = 5;
      int num2 = 10;

// Logical OR operator (||)
if (num1 > 0 || num2 > 20) {
    System.out.println("At least one condition is true.");
} else {
    System.out.println("Both conditions are false.");
}
}
}