package operater;

public class Equal_notEqual_opreator {
	
	// Method to demonstrate equal and not equal operators
    private static void demonstrateEqualityOperators() {
        // Example variables
        int number1 = 5;
        int number2 = 10;
        int number3 = 5;

        // Equal operator (==)
        System.out.println("Equal Operator (==):");
        System.out.println("number1 == number2: " + (number1 == number2));
        System.out.println("number1 == number3: " + (number1 == number3));

        // Not equal operator (!=)
        System.out.println("\nNot Equal Operator (!=):");
        System.out.println("number1 != number2: " + (number1 != number2));
        System.out.println("number1 != number3: " + (number1 != number3));
    }

    // Main method
    public static void main(String[] args) {
        // Call the method to demonstrate equal and not equal operators
        demonstrateEqualityOperators();
    }
}