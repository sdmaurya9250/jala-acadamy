package operater;

public class IncrmentDecr_opreater {

	// Function to perform arithmetic operations
    private static void performArithmeticOperations(int num1, int num2) {
        System.out.println("Addition: " + (num1 + num2));
        System.out.println("Subtraction: " + (num1 - num2));
        System.out.println("Multiplication: " + (num1 * num2));

        // Check for division by zero before performing division
        if (num2 != 0) {
            System.out.println("Division: " + ((double) num1 / num2));
        } else {
            System.out.println("Cannot divide by zero.");
        }
    }

    // Main method
    public static void main(String[] args) {
        // Example numbers
        int number1 = 20;
        int number2 = 5;

        // Call the function to perform arithmetic operations
        performArithmeticOperations(number1, number2);
    }
}
	

