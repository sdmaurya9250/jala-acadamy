package operater;

public class arithmatic {

	 // Method to demonstrate increment and decrement operators
    private static void demonstrateIncrementDecrement() {
        int number = 5;

        // Increment operator (++)
        System.out.println("Initial value: " + number);
        System.out.println("After increment: " + (++number)); // Prefix increment
        System.out.println("Value after prefix increment: " + number);

        number = 5; // Reset the value for demonstration

        System.out.println("\nInitial value: " + number);
        System.out.println("After increment: " + (number++)); // Postfix increment
        System.out.println("Value after postfix increment: " + number);

        number = 10; // Reset the value for demonstration

        // Decrement operator (--)
        System.out.println("\nInitial value: " + number);
        System.out.println("After decrement: " + (--number)); // Prefix decrement
        System.out.println("Value after prefix decrement: " + number);

        number = 10; // Reset the value for demonstration

        System.out.println("\nInitial value: " + number);
        System.out.println("After decrement: " + (number--)); // Postfix decrement
        System.out.println("Value after postfix decrement: " + number);
    }

    // Main method
    public static void main(String[] args) {
        // Call the method to demonstrate increment and decrement operators
        demonstrateIncrementDecrement();
    }
}