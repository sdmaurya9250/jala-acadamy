package operater;

public class relationalOparetor {

	public static void main(String[] args) {

		// Example variables
        int number1 = 5;
        int number2 = 10;

        // Relational operators
        System.out.println("Relational Operators:");

        // Less than (<)
        System.out.println("Less than (<): " + (number1 < number2));

        // Less than or equal to (<=)
        System.out.println("Less than or equal to (<=): " + (number1 <= number2));

        // Greater than (>)
        System.out.println("Greater than (>): " + (number1 > number2));

        // Greater than or equal to (>=)
        System.out.println("Greater than or equal to (>=): " + (number1 >= number2));
    }
}
