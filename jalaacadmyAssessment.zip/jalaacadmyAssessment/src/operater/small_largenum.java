package operater;

public class small_largenum {

	public static void main(String[] args) {

	     // Example variables
        int number1 = 5;
        int number2 = 10;

        // Determine the smaller and larger numbers
        int smallerNumber = (number1 < number2) ? number1 : number2;
        int largerNumber = (number1 > number2) ? number1 : number2;

        // Output the results
        System.out.println("Number 1: " + number1);
        System.out.println("Number 2: " + number2);
        System.out.println("Smaller Number: " + smallerNumber);
        System.out.println("Larger Number: " + largerNumber);
    }
}